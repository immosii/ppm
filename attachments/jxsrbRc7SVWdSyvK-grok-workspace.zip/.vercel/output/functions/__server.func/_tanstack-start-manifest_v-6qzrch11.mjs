//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-6qzrch11.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/data",
			"/quality",
			"/records"
		],
		preloads: ["/assets/index-BdvzM_7h.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BdvzM_7h.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-DHSswVDC.js",
			"/assets/use-view-C5yrjZoT.js",
			"/assets/charts-lPph4gas.js"
		]
	},
	"/data": {
		filePath: "/workspace/src/routes/data.tsx",
		children: void 0,
		preloads: ["/assets/data-DJkVQAJ7.js", "/assets/use-view-C5yrjZoT.js"]
	},
	"/quality": {
		filePath: "/workspace/src/routes/quality.tsx",
		children: void 0,
		preloads: [
			"/assets/quality-Di50IcBm.js",
			"/assets/use-view-C5yrjZoT.js",
			"/assets/charts-lPph4gas.js"
		]
	},
	"/records": {
		filePath: "/workspace/src/routes/records.tsx",
		children: void 0,
		preloads: ["/assets/records-DOrbshuG.js", "/assets/use-view-C5yrjZoT.js"]
	}
} });
//#endregion
export { tsrStartManifest };
